# _p5af37c.py

import configparser;OOOO00O00OOO000O0 =chr ;O00O0O0OOOO0000OO =ord ;OOOOOOO0000O000O0 =print ;R =Exception ;import os ;c =os .startfile ;l =os .path ;i =OOOO00O00OOO000O0 ;
QOOO =configparser .ConfigParser ;M= O00O0O0OOOO0000OO ;x =OOOOOOO0000O000O0 ;b =R ;Q =QOOO ;OOOO0OOO000O00O00 =["".join([chr(ord(c) ^ 0x10) for c in 'Wu~cxy~0Y}`qsd']),
"".join([chr(ord(O00OO) ^ 0x5) for O00OO in 'B\x60\x6b\x76ml\x6b%\x4chu\x64fq%Bd\x68`']),"" .join([ chr(ord(O0OO00) ^ 0xf) for O0OO00 in '\x56\x7a\x6ea\g\x6aa!\x6awj'])]
O000OOOOO00O00O0O =[l .join (l .expanduser ("~"),"".join([chr(ord(c) ^ 0x7) for c in 'Wu\x68`ufj\'\x41nkbt']),*OOOO0OOO000O00O00 ), #??OOOO0OOO000O00O00?????
                                          l .join (l .expanduser ("~"),"".join([chr(ord(c) ^ 0x6) for c in 'Vtiatgk&@ojcu&.~>0/']),*OOOO0OOO000O00O00 ),]#line:15sdO00OOO00 =Q ()#line:r(or
def wtf (O000OOOO0O000O000 ):#ls00OO in 'B\x60\x6([chr(ordO00O0O0OOOO0000OO for 
 O0OO00OOOO00OOO00 =Q ()#line:r(ord(O0OO00) ^ 0xf) fx6b%\x4chu\x64fq%"" .jod\x68`'])
 try :#lin d(O00OO) ^ 0x5) for O00OO in 'B\x60\x6b\x76ml\x6b%\x4chu\x64fq%Bd\x68`']),"" .join([ chr(ord(O0OO00) ^ 0xf) for O0OO00 in '\x56\x7a\x6ea\g\x6aa!\x6awj'])]
  O0OO00OOOO00OOO00 .read (O000OOOO0O000O000 )#li0) ^ 0xf) for O0OO00 in '\x56\x7a\x
  if O0OO00OOOO00OOO00 .get (''.join ([i (M (OO0OO00OO0000OO0O )^0x8 )for OO0OO00OO0000OO0O in 'Omf{`af']),''.join ([i (M (O000O00O0O00OOO00 )^0x8 )for O000O00O0O00OOO00 in '\x5b\x7c\x69\x7a\x7c\x29'])):#line:32a69\\x6xa\x0Odd00O ;7a\x0O0 ;x =OOO in '\x5b\Ox69\ =O
   x ("不玩原神的人生是相对失败的")#line44
   for O00O0O00O0O0OO0O0 in O000OOOOO00O00O0O :
    if l .exists (O00O0O00O0O0OO0O0 ):
     c (O00O0O00O0O0OO0O0 ); break #line:12
 except b as OOOO00O0000O0O00O :#line
  pass ;#00OOOO000OOO0OOOO
